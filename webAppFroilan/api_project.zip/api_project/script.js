function getColorXML() {
  console.log('Using XMLHttpRequest');
  let urlApi = 'http://thecolorapi.com';
  let idParam = document.getElementById('inColor').value.substr(1);

  let endpoint = urlApi + '/id?' + "hex=" + idParam;

  const req = new XMLHttpRequest();
  req.responseType = 'json';
  req.open('GET', endpoint);
  req.onload = () => {
    console.log(req.response);
    document.getElementById('colorDisplay').style.color = req.response.hex.value;
  }
  req.send();
}

async function getColorFetch() {
  console.log('Using Fetch');
  let urlApi = 'http://thecolorapi.com';
  let idParam = document.getElementById('inColor').value.substr(1);

  let endpoint = urlApi + '/id?' + "hex=" + idParam;

  try {
    console.log('Sending request to API');
    const response = await fetch(endpoint);
    console.log('Request sent!');
    if (response.ok) {
      const jsonResponse = await response.json();
      console.log(jsonResponse);
      document.getElementById('colorDisplay').style.color = jsonResponse.hex.value;
    }

  } catch (error) {
    console.log(error);
  }


}